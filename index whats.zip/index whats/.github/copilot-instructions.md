<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

# WhatsApp Message Control System

Este é um sistema de controle de mensagens WhatsApp desenvolvido em HTML, CSS e JavaScript.

## Funcionalidades principais:
- Adicionar números com prefixo wa.me/
- Contar mensagens enviadas por número
- Histórico completo de mensagens
- Interface simples e intuitiva
- Armazenamento local no navegador

## Estrutura do projeto:
- `index.html`: Interface principal
- `styles.css`: Estilos da aplicação
- `script.js`: Lógica da aplicação
- `README.md`: Documentação

## Padrões de código:
- Use JavaScript moderno (ES6+)
- Mantenha funções pequenas e focadas
- Use localStorage para persistência
- Implemente validação de números de telefone
- Mantenha a interface responsiva
